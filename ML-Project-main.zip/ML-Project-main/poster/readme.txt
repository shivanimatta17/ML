we have also added the poster for this project, for better documentation purpose. 
so you can refer to our poster as well for reading about our paper.
