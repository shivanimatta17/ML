dataset = 1. MNIST -> train.csv
          2. EMNIST -> emnist-digits-train.csv
    
put both the data set in the same folder where putting the code

Code for both mnist and emnist is almost same just a minor difference is that keras don't have emnist dataset 
unlike mnist, so we have to read emnist data from .csv file for training purpose of CNN model. 
